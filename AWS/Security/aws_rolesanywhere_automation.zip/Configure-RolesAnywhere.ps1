$profileName = "rolesanywhere"
$trustAnchorArn = "arn:aws:rolesanywhere:<region>:<account-id>:trust-anchor/<trust-anchor-id>"
$profileArn = "arn:aws:rolesanywhere:<region>:<account-id>:profile/<profile-id>"
$roleArn = "arn:aws:iam::<account-id>:role/<role-name>"

$awsConfigPath = "$env:USERPROFILE\.aws\config"

$helperPath = "C:\\aws-rolesanywhere\\aws-signing-helper\\aws_signing_helper.exe"
$certPath = "C:\\aws-rolesanywhere\\certs\\client-cert.pem"
$keyPath = "C:\\aws-rolesanywhere\\certs\\client-key.pem"

if (!(Test-Path -Path "$env:USERPROFILE\.aws")) {
    New-Item -Path "$env:USERPROFILE\.aws" -ItemType Directory
}

$credentialProcessLine = "credential_process = `"$helperPath`" credential-process --certificate `"$certPath`" --private-key `"$keyPath`" --trust-anchor-arn $trustAnchorArn --profile-arn $profileArn --role-arn $roleArn"

@"
[profile $profileName]
region = us-east-1
$credentialProcessLine
"@ | Out-File -FilePath $awsConfigPath -Append -Encoding UTF8

Write-Host "AWS CLI profile '$profileName' configured successfully."