param (
    [string]$SecretName = "my-app-secret",
    [string]$Region = "us-east-1"
)

$env:AWS_PROFILE = "rolesanywhere"

$secret = aws secretsmanager get-secret-value `
    --secret-id $SecretName `
    --region $Region `
    --query SecretString `
    --output text

Write-Host "Secret Value:"
Write-Host $secret