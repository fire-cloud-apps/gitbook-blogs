param (
    [string]$SecretName = "my-app-secret",
    [string]$JsonPath = "C:\myapp\appsettings.Development.json"
)

$env:AWS_PROFILE = "rolesanywhere"

$secretValue = aws secretsmanager get-secret-value `
    --secret-id $SecretName `
    --region us-east-1 `
    --query SecretString `
    --output text

(Get-Content $JsonPath -Raw) `
    -replace '"DbSecret"\s*:\s*".*?"', '"DbSecret": "' + $secretValue + '"' |
    Set-Content $JsonPath

Write-Host "Injected secret into $JsonPath"